const { Storage } = require('@google-cloud/storage');
const axios = require('axios');
const stream = require('stream');
const path = require('path');


// Function to upload a file from an external URL to the GCS bucket
async function getUrls() {
    let data_on = false;
    let f_urls = [];
    while(!data_on){
        await axios.post("https://jholashop.com/webhook/get-product-images", {
            laptop: 1
        }).then((response) => {
            data_on = true;
            f_urls = response.data;
        })
        .catch((error) => {
            //console.log(error);
        });
    }
    //console.log(f_urls);
    return f_urls;
}

//Start Program

let urls = [];

(async () => {

    let start = true;
    let count = 0;
    while(start){
        count++;
        if(urls.length < 1){
            urls = await getUrls();
        }
        for(let i = 0; i < urls.length; i++) {
            const value = urls[i];
            console.log(value.url);
        }
        if(count > 5){
            start = false;
        }
        console.log('-----------------------------------------------');
        urls = [];
    }

})();


