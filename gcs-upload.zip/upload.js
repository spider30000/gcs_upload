const { Storage } = require('@google-cloud/storage');
const axios = require('axios');
const stream = require('stream');
const path = require('path');
const cluster = require('cluster');

// Initialize the Google Cloud Storage client with your service account key
const storage = new Storage({ keyFilename: 'credentials/jhola-service-account.json' });

// Specify the name of your GCS bucket
const bucketName = 'jholashop';

(async () => {

if (cluster.isMaster) {
    // Master process
    for (let i = 0; i < 5; i++) {
      cluster.fork(); // Fork a worker process
      await new Promise(resolve => setTimeout(resolve, 30000));
      console.log('Worker '+i+' Started');
    }
    
} else {
// Worker process

    // Function to upload a file from an external URL to the GCS bucket
    async function uploadFileFromURL(url, remoteFileName) {
    try {
        // Use axios to fetch the file from the external URL
        const response = await axios({ method: 'get', url, responseType: 'stream' });

        // Create a writable stream to upload the file to GCS
        const fileStream = new stream.PassThrough();

        // Pipe the response data from the external URL to the GCS stream
        response.data.pipe(fileStream);

        // Upload the file stream to the GCS bucket
        const file = storage.bucket(bucketName).file(remoteFileName);
        await new Promise((resolve, reject) => {
        fileStream.pipe(file.createWriteStream(
                {
                    metadata: {
                    contentType: response.headers['content-type'],
                    acl: [{ entity: 'allUsers', role: 'READER' }] // publicRead
                    }
                }
            ))
            .on('error', reject)
            .on('finish', () => {
            //console.log(`File uploaded from URL to ${bucketName}/${remoteFileName}`);
            resolve();
            });
        });
    } catch (err) {
        console.error('Error uploading file from URL:', err);
    }
    }

    // Function to upload a file from an external URL to the GCS bucket
    async function getUrls() {
        let data_on = false;
        let f_urls = [];
        while(!data_on){
            await axios.post("https://jholashop.com/webhook/get-product-images", {
                laptop: 1
            }).then((response) => {
                data_on = true;
                f_urls = response.data;
            })
            .catch((error) => {
                //console.log(error);
            });
        }
        //console.log(f_urls);
        return f_urls;
    }

    //Start Program

    let urls = [];

    (async () => {

        let start = true;
        let count = 0;
        while(start){
            count++;
            if(urls.length < 1){
                urls = await getUrls();
            }
            for(let i = 0; i < urls.length; i++) {
                const value = urls[i];
                // Example usage
                const fileURL = value.url; // Replace with the external file URL
                const remoteFileName = value.gcs_url; // Specify the desired remote filename in GCS

                await uploadFileFromURL(fileURL, remoteFileName);

                console.log('== Image '+value.id+' Uploaded');

            }
            if(count > 1){
                start = false;
            }
            console.log('-----------------------------------------------');
            urls = [];
        }

    })();

}

})();